
package minheap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Scanner;
import java.text.Normalizer;
import static javafx.scene.input.KeyCode.T;
/**
 *
 * @author EESPINOSRU
 */
public class Pruebas <T> {

    /**
     * @param args the command line arguments
     */
    public static String cleanString(String texto) {
        texto = Normalizer.normalize(texto, Normalizer.Form.NFD);
        texto = texto.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
        return texto;
    }
    public static void main(String[] args) {
        char arr[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',};
        Trie<String> t = new Trie(arr);
        Scanner sc = null;
        String[] lista = new String[90000], aux;
        int i = 0;
        boolean ban;
        long TInicio, TFin, tiempo;
        Sort s = new Sort();
        
        try {
            File file = new File("wiki-100k.txt");
            Scanner leeArch = new Scanner(file);
            String palabra;
            palabra = leeArch.nextLine();
            palabra = palabra.substring(1);
            while (i < 4000) {
                palabra = leeArch.nextLine();
                
                palabra = cleanString(palabra);
              
                if((palabra.contains("'") || palabra.contains("#") || palabra.contains(" ") || palabra.contains("©") || palabra.contains("æ") || palabra.contains("«") || palabra.contains("ß") ||palabra.contains("Ã") ||palabra.contains(".") ||palabra.contains("-") ||palabra.contains("¹") ||palabra.contains("å") ||palabra.contains("¿") ||palabra.contains("ö") ||palabra.contains("ø") ||palabra.contains("þ") ||palabra.contains("¡") ||palabra.contains("ª") ||palabra.contains(":") ||palabra.contains("¨") ||palabra.contains("»") ||palabra.contains("§") ||palabra.contains("º") ||palabra.contains("±") ||palabra.contains("¦") ||palabra.contains("ð")))
                   palabra = "";
                else{
                   // System.out.print("\n imoprimr: " + palabra);
                   if(palabra!= null)
                        lista[i] = palabra;
                }
                i++;
            }
            leeArch.close();
            
        } catch (Exception e) {
           throw new NullPointerException("Error"); 
        }
        //Verficamos se encuentren los datos y la cantidad de agregados
       /*  for (int k1 = 0; k1<100;k1++){
            System.out.println(lista[k1]);
            System.out.println("i: " + i);
        }*/

        int tam = i-1;
        double prom=0; 
        int cont = 0;
        for(int k=0; k<100; k++){
        MinHeap<String> minHeap = new MinHeap(tam);
        TInicio = System.currentTimeMillis();
            for (int j = 0; j < tam+1; j++) {

                minHeap.inserta(lista[j]);
                
             }
        
        Object[] res3 =  minHeap.heapSort();
        
        TFin = System.currentTimeMillis();
        tiempo = TFin - TInicio;
        prom+=tiempo;
        minHeap.imprime();
        
        }
        System.out.print("Tiempo promedio en Heap: ");
        System.out.println(prom/100.0);
        
        //Prueba Trie 
  
        prom=0;
        
        char[] sim = {'a','b', 'c','d','e', 'f','g','h', 'i','j','k', 'l','m',
             'n','ñ', 'o', 'p','q', 'r','s','t', 'u','v','w', 'x','y','z'};
        String palabra=null;
        Trie a = new Trie(sim);
                try {
            File file = new File("wiki-100k.txt");
            Scanner leeArch = new Scanner(file);
            
            palabra = leeArch.nextLine();
            palabra = palabra.substring(1);
            while (leeArch.hasNextLine()) {
                palabra = leeArch.nextLine();
                
                palabra = cleanString(palabra).toLowerCase();
              
                if((palabra.contains("'") || palabra.contains("#") || palabra.contains(" ") || palabra.contains("Â©") || palabra.contains("Ã¦") || palabra.contains("Â«") || palabra.contains("ÃŸ") ||palabra.contains("Ãƒ") ||palabra.contains(".") ||palabra.contains("-") ||palabra.contains("Â¹") ||palabra.contains("Ã¥") ||palabra.contains("Â¿") ||palabra.contains("Ã¶") ||palabra.contains("Ã¸") ||palabra.contains("Ã¾") ||palabra.contains("Â¡") ||palabra.contains("Âª") ||palabra.contains(":") ||palabra.contains("Â¨") ||palabra.contains("Â»") ||palabra.contains("Â§") ||palabra.contains("Âº") ||palabra.contains("Â±") ||palabra.contains("Â¦") ||palabra.contains("Ã°")||palabra.contains("ß")||palabra.contains("©")||palabra.contains("æ")||palabra.contains("©")||palabra.contains("«"))) 
                   palabra = "";
                else{
                    
                    a.insertar(palabra);
                    
                }
                
            }
            leeArch.close();
            
        } catch (Exception e) {
           throw new NullPointerException("Error"+e); 
        }
        for (int k = 0; k < 100; k++) {
        t = new Trie(sim);
        TInicio = System.currentTimeMillis();
        for (int j = 0; j < tam; j++) {
            t.insertar(lista[j]);
        }
        t.display();
        TFin = System.currentTimeMillis();
        tiempo = TFin - TInicio;
         prom+=tiempo;
        }
        System.out.print("Tiempo promedio en Trie: ");
        System.out.println(prom/100.0);
        //Prueba Merge Sort

         prom=0; 
         aux = new String[tam];
        for (int j = 0; j < tam; j++) {
            aux[j] = lista[j];
        }
        for(int k=0; k<100;k++){      

        TInicio = System.currentTimeMillis();
        s.mergeSort1(aux);
        TFin = System.currentTimeMillis();
        tiempo = TFin - TInicio;
        prom+=tiempo;

        }
        System.out.print("Tiempo promedio en Merge Sort: ");
        System.out.println(prom/100);
       //casi listo
    }

}
